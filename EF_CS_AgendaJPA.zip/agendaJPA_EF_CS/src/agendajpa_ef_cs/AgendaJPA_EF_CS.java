/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agendajpa_ef_cs;

/**
 *
 * @author estudiante
 */
public class AgendaJPA_EF_CS {

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AgendaTelefonica {
    private Map<String, String> contactos;
    private Map<String, Integer> llamadas;

    public AgendaTelefonica() {
        contactos = new HashMap<>();
        llamadas = new HashMap<>();
    }

    public void agregarContacto(String nombre, String telefono) {
        contactos.put(nombre, telefono);
    }

    public void eliminarContacto(String nombre) {
        contactos.remove(nombre);
    }

    public void realizarLlamada(String nombre) {
        if (contactos.containsKey(nombre)) {
            int llamadasActuales = llamadas.getOrDefault(nombre, 0);
            llamadas.put(nombre, llamadasActuales + 1);
            System.out.println("Llamada realizada a " + nombre);
        } else {
            System.out.println("No se encontró el contacto " + nombre);
        }
    }

    public void generarReporteLlamadas() {
        System.out.println("Reporte de llamadas:");
        for (Map.Entry<String, Integer> entry : llamadas.entrySet()) {
            String nombre = entry.getKey();
            int cantidadLlamadas = entry.getValue();
            System.out.println(nombre + ": " + cantidadLlamadas + " llamada(s)");
        }
    }

    public static void main(String[] args) {
        AgendaTelefonica agenda = new AgendaTelefonica();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Agregar contacto");
            System.out.println("2. Eliminar contacto");
            System.out.println("3. Realizar llamada");
            System.out.println("4. Generar reporte de llamadas");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el salto de línea

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del contacto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese el teléfono del contacto: ");
                    String telefono = scanner.nextLine();
                    agenda.agregarContacto(nombre, telefono);
                    System.out.println("Contacto agregado correctamente");
                    break;
                case 2:
                    System.out.print("Ingrese el nombre del contacto a eliminar: ");
                    nombre = scanner.nextLine();
                    agenda.eliminarContacto(nombre);
                    System.out.println("Contacto eliminado correctamente");
                    break;
                case 3:
                    System.out.print("Ingrese el nombre del contacto para realizar la llamada: ");
                    nombre = scanner.nextLine();
                    agenda.realizarLlamada(nombre);
                    break;
                case 4:
                    agenda.generarReporteLlamadas();
                    break;
                case 5:
                    System.out.println("¡Hasta luego!");
                    System.exit(0);
                default:
                    System.out.println("Opción inválida");
                    break;
            }
        }
    }
}
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
