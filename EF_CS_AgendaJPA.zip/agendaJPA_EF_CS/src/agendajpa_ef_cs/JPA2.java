/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agendajpa_ef_cs;

/**
 *
 * @author estudiante
 */
public class JPA2 {
  import javax.persistence.EntityManager;
  import javax.persistence.EntityManagerFactory;
  import javax.persistence.EntityTransaction;
  import javax.persistence.Persistence;
  import java.util.List;

public class AgendaTelefonica {
    private EntityManagerFactory emf;

    public AgendaTelefonica() {
        emf = Persistence.createEntityManagerFactory("AgendaTelefonicaPU");
    }

    public void agregarContacto(String nombre, String telefono) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        Contacto contacto = new Contacto();
        contacto.setNombre(nombre);
        contacto.setTelefono(telefono);
        em.persist(contacto);  
}
